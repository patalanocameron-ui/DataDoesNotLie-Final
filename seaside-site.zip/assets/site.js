(() => {
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  // App bar: shrink on scroll, hide on scroll down, show on scroll up
  const bar = $('.appbar'), fab = $('.fab'), prog = $('.progress');
  let lastY = scrollY, ticking = false;
  const onScroll = () => {
    const y = scrollY;
    bar && bar.classList.toggle('scrolled', y > 24);
    if (bar && !document.body.classList.contains('drawer-open')) bar.classList.toggle('hide', y > 500 && y > lastY + 4);
    if (bar && y < lastY - 4) bar.classList.remove('hide');
    fab && fab.classList.toggle('show', y > 520);
    if (prog) {
      const a = $('.article'); if (a) {
        const r = a.getBoundingClientRect(); const t = Math.min(1, Math.max(0, -r.top / (r.height - innerHeight * .6)));
        prog.style.transform = `scaleX(${t})`;
      }
    }
    if (!reduce) parallax();
    lastY = y; ticking = false;
  };
  addEventListener('scroll', () => { if (!ticking) { requestAnimationFrame(onScroll); ticking = true; } }, { passive: true });

  // Parallax (data-parallax="0.15") and hero zoom
  const px = $$('[data-parallax]'); const hero = $('.hero-media img');
  function parallax() {
    const vh = innerHeight;
    px.forEach(el => {
      const r = el.parentElement.getBoundingClientRect();
      if (r.bottom < -200 || r.top > vh + 200) return;
      const k = parseFloat(el.dataset.parallax) || .12;
      el.style.transform = `translate3d(0,${((r.top + r.height / 2) - vh / 2) * -k}px,0)`;
    });
    if (hero && scrollY < vh * 1.2) {
      hero.style.animation = 'none';
      hero.style.transform = `scale(${1.02 + scrollY / vh * .12}) translate3d(0,${scrollY * .18}px,0)`;
    }
  }

  // Reveal on scroll
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
  }), { threshold: .14, rootMargin: '0px 0px -6% 0px' });
  $$('[data-reveal],.clip,.mask').forEach(el => io.observe(el));
  $$('[data-stagger]').forEach(g => [...g.children].forEach((c, i) => { c.style.setProperty('--i', i); c.setAttribute('data-reveal', c.getAttribute('data-reveal') || ''); io.observe(c); }));

  // Word-by-word statement highlight
  $$('.statement[data-words]').forEach(st => {
    const walk = n => [...n.childNodes].forEach(c => {
      if (c.nodeType === 3) {
        const f = document.createDocumentFragment();
        c.textContent.split(/(\s+)/).forEach(w => { if (/^\s+$/.test(w) || !w) f.append(w); else { const s = document.createElement('span'); s.className = 'word'; s.textContent = w; f.append(s); } });
        c.replaceWith(f);
      } else walk(c);
    });
    walk(st);
    const words = $$('.word', st);
    const upd = () => {
      const r = st.getBoundingClientRect(); const p = Math.min(1, Math.max(0, (innerHeight * .85 - r.top) / (r.height + innerHeight * .35)));
      const n = reduce ? words.length : Math.round(p * words.length);
      words.forEach((w, i) => w.classList.toggle('on', i < n));
    };
    addEventListener('scroll', upd, { passive: true }); upd();
  });

  // Sticky story steps
  const story = $('.story');
  if (story) {
    const imgs = $$('.story-media img', story), steps = $$('.step', story), cnt = $('.story-media .count b', story);
    const sio = new IntersectionObserver(es => es.forEach(e => {
      if (!e.isIntersecting) return;
      const i = steps.indexOf(e.target);
      steps.forEach((s, j) => s.classList.toggle('on', j === i));
      imgs.forEach((m, j) => m.classList.toggle('on', j === i));
      if (cnt) cnt.textContent = i + 1;
    }), { rootMargin: '-45% 0px -45% 0px' });
    steps.forEach(s => sio.observe(s));
  }

  // Rails
  $$('[data-rail]').forEach(w => {
    const rail = $('.rail', w);
    $$('[data-dir]', w).forEach(b => b.addEventListener('click', () => {
      const card = rail.firstElementChild; const step = card ? card.getBoundingClientRect().width + 22 : 340;
      rail.scrollBy({ left: step * (+b.dataset.dir), behavior: reduce ? 'auto' : 'smooth' });
    }));
  });

  // Material ripple
  document.addEventListener('pointerdown', e => {
    const b = e.target.closest('.btn,.fab,.rail-ctrl button'); if (!b || reduce) return;
    const r = b.getBoundingClientRect(), d = Math.max(r.width, r.height) * 2.2;
    const s = document.createElement('span'); s.className = 'ripple';
    s.style.cssText = `width:${d}px;height:${d}px;left:${e.clientX - r.left - d / 2}px;top:${e.clientY - r.top - d / 2}px`;
    b.appendChild(s); setTimeout(() => s.remove(), 650);
  });

  // Drawer
  const open = v => { document.body.classList.toggle('drawer-open', v); const m = $('.menu-btn'); m && m.setAttribute('aria-expanded', v); };
  $$('[data-drawer-open]').forEach(b => b.addEventListener('click', () => open(true)));
  $$('[data-drawer-close],.scrim').forEach(b => b.addEventListener('click', () => open(false)));
  addEventListener('keydown', e => e.key === 'Escape' && open(false));

  // Weekly drop status, in Ormond Beach time. Orders usually open Sunday and close Wednesday at noon.
  const status = $$('[data-drop-status]');
  if (status.length) {
    const p = new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', weekday: 'short', hour: 'numeric', hour12: false }).formatToParts(new Date());
    const wd = p.find(x => x.type === 'weekday').value, hr = +p.find(x => x.type === 'hour').value;
    const isOpen = ['Sun', 'Mon', 'Tue'].includes(wd) || (wd === 'Wed' && hr < 12);
    status.forEach(el => {
      el.innerHTML = isOpen
        ? '<span class="dot"></span>This week’s menu is usually open until Wednesday at noon'
        : '<span class="dot closed"></span>Pickup weekend. The next menu usually opens Sunday';
    });
  }

  // Snackbar nudge for drop alerts (once per visitor)
  const sb = $('.snackbar');
  if (sb) {
    let shown = false; try { shown = localStorage.getItem('ss-snack') === '1'; } catch (e) {}
    if (!shown) {
      const go = () => { if (scrollY > innerHeight * 1.6) { sb.classList.add('show'); removeEventListener('scroll', go); try { localStorage.setItem('ss-snack', '1'); } catch (e) {} setTimeout(() => sb.classList.remove('show'), 9000); } };
      addEventListener('scroll', go, { passive: true });
    }
    $('[data-snack-close]', sb)?.addEventListener('click', () => sb.classList.remove('show'));
  }

  // Year
  $$('[data-year]').forEach(e => e.textContent = new Date().getFullYear());
  onScroll();
})();
